This folder contains the codes from https://github.com/guohuayan/WSR-maximization-for-RIS-system
