# IRSconfigurationDRL

Source code for Wei Wang and Wei Zhang, "Intelligent Reflecting Surface Configurations for Smart Radio Using Deep Reinforcement Learning", IEEE JSAC.

Author Contacts：richardwangseu@gmail.com
