# deepChannelLearning4RIS
Channel Estimation for Reconfigurable Intelligent Surface via Deep Learning
MATLAB Codes for the paper: 

A. M. Elbir, A Papazafeiropoulos, P. Kourtessis, and S. Chatzinotas, "Deep Channel Learning For Large Intelligent Surfaces Aided mm-Wave Massive MIMO Systems", IEEE Wireless Communications Letters, in press, 2020.

Prepared by Ahmet M. Elbir, 2020, Please cite the above work if you use this code. e-mail me for questions via: ahmetmelbir@gmail.com 

This includes the data generation for the training dataset and model training.

This document is prepared upon request from the colleagues. The code includes several unnecesary parts. I will update it soon.
